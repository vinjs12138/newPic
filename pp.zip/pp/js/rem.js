var html=document.getElementsByTagName("html")[0];
var a = html.offsetWidth/25;
// console.log(a)

html.style.fontSize = a+ "px";